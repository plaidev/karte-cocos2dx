//
//  KarteBridgeLoader.m
//  Cocos2dxSample-mobile
//
//  Created by koichi tanaka on 2020/07/15.
//

#import "KarteBridgeLoader.h"

@implementation KarteBridgeLoaderInternal

+ (void)handleLoad
{
}

@end

@implementation KarteBridgeLoader

+ (void)load
{
    [super load];
    [self handleLoad];
}

@end
